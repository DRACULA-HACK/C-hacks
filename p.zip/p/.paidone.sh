echo -e " \033[1;31m By "
figlet MASTER-HACK |pv -qL 50 | lolcat
sleep 8
clear
figlet INVADERS ofc | pv -qL 50 | lolcat
sleep 8
clear
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
echo -e "


"
echo -e "\033[1;32m    buy this for only good purposes am not responsible for harming anyone or anything  "

echo -e "


\033[1;31m
		(1) whatsapp hacking package  1000₹

		(2) facebook hacking package 600₹

		(3) instagram hacking package 600₹

		(4) rat,ransomware and spyware Package 2000₹

		(5) android hacking package 1000₹

		(6) hacking course 2000₹

		(7) carding stuff 1000₹

		(8) social Media baning cracking crashing package

		(9) paid tools and methods

		(10) other courses or doubts

"
read -p " :- " buy

if [ $buy = 1 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260

elif [ $buy = 2 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
elif [ $buy = 3 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
elif [ $buy = 4 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
elif [ $buy = 5 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
elif [ $buy = 6 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
elif [ $buy = 7 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
elif [ $buy = 8 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
elif [ $buy = 9 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
elif [ $buy = 10 ];then

xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260
sleep 30
xdg-open https://wa.me//+916235369260

else
echo "mm oky "
cd ..

bash chack.sh

fi
